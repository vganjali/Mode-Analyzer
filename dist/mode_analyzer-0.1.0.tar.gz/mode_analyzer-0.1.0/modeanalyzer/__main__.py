import sys
sys.path.append('./')
from modeanalyzer import *
from modeanalyzer import main

app = main()
app.run()
# Run = RunSimulation()
# root = Tk.Tk()
# main_gui = MainWindow(master=root)
# root.read = read_data(f)
# root.mainloop()