from modeanalyzer import *

app = main()
app.run()
# Run = RunSimulation()
# root = Tk.Tk()
# main_gui = MainWindow(master=root)
# root.read = read_data(f)
# root.mainloop()